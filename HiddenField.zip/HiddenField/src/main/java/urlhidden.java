import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet("/urlhidden")

public class urlhidden extends HttpServlet 
{
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String x=request.getParameter("id");
		String formid=request.getParameter("frm");
		if(formid.equals("1"))
		{
			out.println("The value is "+formid);
			out.println("The value of ID is "+x);
			out.println("This is an example of Hidden Field<br>");
		}
		else
		{
			out.println("This is not an example of Hidden Field<br>");
		}

	}
}