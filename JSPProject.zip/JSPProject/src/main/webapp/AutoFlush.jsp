<h1>Hello World!</h1>
        <select name="number">
            <%
            for(int i=0;i<100;i++)
                {
            %>
            <option value="<%=i%>"><%=i%></option>
            <%
            }
            %>
        </select>
    </body>
