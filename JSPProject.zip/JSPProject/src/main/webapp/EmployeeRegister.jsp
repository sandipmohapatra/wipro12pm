<%@ page import="java.sql.*" %>

<%String a=request.getParameter("t1");
String b=request.getParameter("t2");
String c=request.getParameter("t3");
String d=request.getParameter("b1");%>

<%out.println("Empno is "+a);
out.println("Name is "+b);
out.println("Address is "+c);
out.println("Button pressed is "+d);
%>
<%
Connection con=null;
try
{
	Class.forName("com.mysql.cj.jdbc.Driver");
	 con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mphasis237","root","1234");
}
catch(Exception ae)
{
	ae.printStackTrace();
}
if(d.equals("insert"))
{
	PreparedStatement ps;
	try {
		ps = con.prepareStatement("insert into jdbcexample values(?,?,?)");
		ps.setInt(1,Integer.parseInt(a));
		ps.setString(2,b);
		ps.setString(3,c);
		ps.execute();
		out.println("row inserted");
	}
	catch (SQLException e) 
	{
				e.printStackTrace();
	}
}
		else if(d.equals("update"))
	{
			PreparedStatement ps;
			try {
				ps = con.prepareStatement("update jdbcexample set name=?, address=? where empno=?");
				
				ps.setString(1,b);
				ps.setString(2,c);
				ps.setInt(3,Integer.parseInt(a));
				ps.execute();
				out.println("row updated");
			}
			catch (SQLException e) 
			{
						e.printStackTrace();
			}
	}
	else if(d.equals("delete"))
	{
		PreparedStatement ps;
		try {
			ps = con.prepareStatement("delete from jdbcexample where empno=?");
			ps.setInt(1,Integer.parseInt(a));
			ps.execute();
			out.println("row deleted");
		}
		catch (SQLException e) 
		{
					e.printStackTrace();
		}
	}
	else if(d.equals("select"))
	{
		Statement ps;
		try {
			ps = con.createStatement();
			ResultSet rs=ps.executeQuery("select * from jdbcexample");
			out.println("<table border=1><tr><td><b>Empno<td><b>Name<td><b>Address</tr>");
		while(rs.next())
		{
			out.println("<tr><td>"+rs.getInt(1)+"<td>"+rs.getString(2)+"<td>"+rs.getString(3)+"</tr>");
		}
		out.println("</table>");
		}
		catch (SQLException e) 
		{
					e.printStackTrace();
		}
}
	else
	{
		PreparedStatement ps;
		try {
			ps = con.prepareStatement("select * from jdbcexample where address=?");
			ps.setString(1,c);
			ResultSet rs=ps.executeQuery();
			out.println("<table border=1><tr><td><b>Empno<td><b>Name<td><b>Address</tr>");
		while(rs.next())
		{
			out.println("<tr><td>"+rs.getInt(1)+"<td>"+rs.getString(2)+"<td>"+rs.getString(3)+"</tr>");
		}
		out.println("</table>");
		}
		catch (SQLException e) 
		{
					e.printStackTrace();
		}
	}
%>

