<body>
        <h1>Hello World!</h1>
//expression tag
       
 <%
        out.print("expression=");
        %>

        <%= 5+4 %>


//declarative

        <%int sum, a, b;%>
        <%
              a=10;
              b=20;

        sum=a+b;
        out.println("the sum of numbers is"+sum);

        %>

     <%=5+4 %>
      
        <font color="red" size="4">
            the sum of <%=a%> and <%=b%> is <%=sum%>

        </font>
                     

    </body>

