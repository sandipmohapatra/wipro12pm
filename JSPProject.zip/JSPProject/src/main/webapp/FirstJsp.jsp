 <body>
        <h1>Hello World!</h1>
        <form action="second.jsp">
            username:<input type="text" name="user">
            <input type="submit" value="submit">
       </form>
    </body>
</html>
