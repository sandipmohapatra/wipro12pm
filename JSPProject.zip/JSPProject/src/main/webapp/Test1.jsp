<body>
        <form action="test2.jsp">
            age=<input type="text" name="n1">
            <input type="submit" value="submit">
        </form>
    </body>

