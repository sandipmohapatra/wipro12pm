<%@page isErrorPage="true" %>
<%

out.println("enter only the number");
out.println("<a href='Test1.jsp'>form</a>");

%>

