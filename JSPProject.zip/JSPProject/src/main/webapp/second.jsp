<body>
      <%!String user;%>
      <%
      user=request.getParameter("user");
      out.println("the value of user is="+user);
      %>
   
      <br>
      the username is=<%=user%>
    </body>
