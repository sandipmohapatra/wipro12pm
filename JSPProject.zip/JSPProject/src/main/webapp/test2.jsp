<%@page errorPage="error.jsp"%>

<%!String name;
    int age;
    %>
          
    <% name=request.getParameter("n1");
    age=Integer.parseInt(name);
    out.println("the age is"+age);%>
