<%!String age;
int age1;%>
<%
try
{
age=request.getParameter("n1");
age1=Integer.parseInt(age);
out.println("the age is "+age1);
}
catch(Exception e)
        {
    out.println("plz enter only numbers");
    %>

   <%@include file="test4.jsp"%>

   <%
    }
    %>

