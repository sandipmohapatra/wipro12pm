import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet("/urlrewrite1")
public class urlrewrite1 extends HttpServlet 
{
     protected void service(HttpServletRequest request, HttpServletResponse response)
             throws ServletException, IOException {
          response.setContentType("text/html");
          PrintWriter out = response.getWriter();
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet login</title>");  
            out.println("</head>");
            out.println("<body bgcolor='orange'>");
            out.println("<h1>Login page</h1>");
            out.println("Second servlet class<br>");
            String name1=request.getParameter("name");
            out.println("The name is="+name1);
            String address=request.getParameter("a2");
            out.println("The address is="+address);
            String salary=request.getParameter("salary");
            out.println("The salary is="+salary);
            out.println("</body>");
            out.println("</html>");
     }       
     }