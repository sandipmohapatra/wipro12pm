import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet("/urlrewriting")
public class urlrewriting extends HttpServlet {

     protected void service(HttpServletRequest request, HttpServletResponse response)
             throws ServletException, IOException {
          response.setContentType("text/html");
          PrintWriter out = response.getWriter();
          String name=request.getParameter("user");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>url rewriting</title>");  
            out.println("</head>");
            out.println("<body bgcolor='orange'>");
            out.println("This is first servlet class<br>");
            out.println("The username="+name+"<br>");
            out.println("<a href='urlrewrite1?name="+name+"'>click1</a>");
            out.println("<a href='urlrewrite1?name="+name+"&a2=Bangalore&salary=12000'> click2</a>");
            out.println("</form>");
            out.println("</body>");
            out.println("</html>");
           
          }
     }

